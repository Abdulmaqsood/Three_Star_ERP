<?php $__env->startSection('content'); ?>
    <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Toolbar-->
        <div class="toolbar" id="kt_toolbar">
            <div class=" container-fluid  d-flex flex-stack flex-wrap flex-sm-nowrap">
                <!--begin::Info-->
                <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                    <!--begin::Title-->
                    <h1 class="text-dark fw-bold my-1 fs-2">
                        Edit Product </h1>
                    <!--end::Title-->

                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb fw-semibold fs-base my-1">
                        <li class="breadcrumb-item text-muted">
                            <a href="<?php echo e(route('dashboard')); ?>" class="text-muted text-hover-primary">
                                Home </a>
                        </li>

                        <li class="breadcrumb-item text-muted">
                            Store Management </li>

                        <li class="breadcrumb-item text-muted">
                            Products </li>

                        <li class="breadcrumb-item text-dark">
                            Edit Product </li>

                    </ul>
                    <!--end::Breadcrumb-->
                </div>
                <!--end::Info-->


            </div>
        </div>
        <!--end::Toolbar-->

        <!--begin::Post-->
        <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div class=" container-fluid ">
                <!--begin::Form-->
                <form action="<?php echo e(route('update.product', $product->Id)); ?>" method="POST"
                    class="form d-flex flex-column flex-lg-row fv-plugins-bootstrap5 fv-plugins-framework"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php
                        $myProduct = App\Models\Product::where('quickbook_id', $product->Id)
                            ->with('category', 'subCategory', 'vendor', 'manufacturer')
                            ->first();
                    ?>
                    <!--begin::Aside column-->
                    <div class="d-flex flex-column gap-7 gap-lg-10 w-100 w-lg-300px mb-7 me-lg-10">

                        <!--begin::Category & tags-->
                        <div class="card card-flush py-4">
                            <!--begin::Card header-->
                            <div class="card-header">
                                <!--begin::Card title-->
                                <div class="card-title">
                                    <h2>Add Category</h2>
                                </div>
                                <!--end::Card title-->
                            </div>
                            <!--end::Card header-->

                            <!--begin::Card body-->
                            <div class="card-body pt-0">
                                <!--begin::Input group-->
                                <!--begin::Label-->
                                <label class="required form-label">Categories</label>
                                <!--end::Label-->

                                <!--begin::Input-->
                                <select name="category_id" data-placeholder="Select a Category..."
                                    class="form-select form-select-solid fw-bold ">
                                    <?php if($categories): ?>
                                        <option value="">Select main category...
                                        </option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"
                                                <?php if($category->id == $myProduct->category->id): ?> selected <?php endif; ?>><?php echo e($category->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option disabled>Main Category Not available...
                                        </option>
                                    <?php endif; ?>


                                </select>
                                <!--end::Input-->
                                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger">Category Required</span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!--end::Input group-->
                                <!--begin::Button-->
                                <a href="<?php echo e(route('add.category')); ?>" class="btn btn-light-primary btn-sm mb-10 mt-3">
                                    <i class="ki-duotone ki-plus fs-2"></i> Create main category
                                </a>
                                <!--end::Button-->
                                <!--begin::Label-->
                                <label class=" form-label">SubCategories</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <select name="sub_category_id" data-placeholder="Select a Category..."
                                    class="form-select form-select-solid fw-bold ">
                                    <?php if($sub_categories): ?>
                                        <option value="">Select subCategory...
                                        </option>
                                        <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"
                                                <?php if($myProduct->subCategory && $myProduct->subCategory->id == $category->id): ?> selected <?php endif; ?>>
                                                <?php echo e($category->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option disabled>SubCategory Not available...
                                        </option>
                                    <?php endif; ?>


                                </select>
                                <!--end::Input-->
                                <?php $__errorArgs = ['sub_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger">SubCategory Required</span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!--end::Input group-->

                                <!--begin::Button-->
                                <a href="<?php echo e(route('add.subCategory')); ?>" class="btn btn-light-primary btn-sm mb-10 mt-3">
                                    <i class="ki-duotone ki-plus fs-2"></i> Create subCategory
                                </a>
                                <!--end::Button-->

                          
                            </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Category & tags-->
                        <!--begin::Category & tags-->
                        <div class="card card-flush py-4">
                            <!--begin::Card header-->
                            <div class="card-header">
                                <!--begin::Card title-->
                                <div class="card-title">
                                    <h2>Vendor Detail</h2>
                                </div>
                                <!--end::Card title-->
                            </div>
                            <!--end::Card header-->

                            <!--begin::Card body-->
                            <div class="card-body pt-0">
                                <!--begin::Input group-->
                                <!--begin::Label-->
                                <label class=" form-label">Vendors</label>
                                <!--end::Label-->

                                <!--begin::Input-->
                                <select name="vendor_id" data-placeholder="Select a Country..."
                                    class="form-select form-select-solid fw-bold ">
                                    <?php if($vendors): ?>
                                        <option value="">Select vendors...
                                        </option>
                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($vendor->id); ?>"
                                                <?php if($vendor->id == $myProduct->vendor->id): ?> selected <?php endif; ?>><?php echo e($vendor->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option disabled>Vendors Not available...
                                        </option>
                                    <?php endif; ?>


                                </select>
                                <!--end::Input-->
                                <?php $__errorArgs = ['vendor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger">Vendor Required</span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                <!--end::Input group-->

                                <!--begin::Button-->
                                <a href="<?php echo e(route('add.vendor')); ?>" class="btn btn-light-primary btn-sm mb-10 mt-3">
                                    <i class="ki-duotone ki-plus fs-2"></i> Create new Vendor
                                </a>
                                <!--end::Button-->
                                <!--begin::Input group-->
                                <div class="fv-row mb-7">
                                    <!--begin::Label-->
                                    <label class=" form-label">Vendor Code</label>
                                    <!--end::Label-->

                                    <!--begin::Input-->
                                    <input type="text" name="vendor_code" class="form-control mb-2"
                                        placeholder="Vendor Code..." value="<?php echo e($myProduct->vendor_code); ?>">
                                    <!--end::Input-->

                                    <?php $__errorArgs = ['vendor_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Label-->
                                <label class=" form-label">Manufacturer</label>
                                <!--end::Label-->

                                <!--begin::Input-->
                                <select name="manufacturer_id" data-placeholder="Select a Country..."
                                    class="form-select form-select-solid fw-bold ">
                                    <?php if($manufacturers): ?>
                                        <option value="">Select manufacturers...
                                        </option>
                                        <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($manufacturer->id); ?>"
                                                <?php if($manufacturer->id == $myProduct->manufacturer->id): ?> selected <?php endif; ?>><?php echo e($manufacturer->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option disabled>Manufacturer Not available...
                                        </option>
                                    <?php endif; ?>


                                </select>
                                <!--end::Input-->
                                <?php $__errorArgs = ['manufacturer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger">Manufacturer Required</span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                <!--end::Input group-->

                                <!--begin::Button-->
                                <a href="<?php echo e(route('add.manufacturer')); ?>" class="btn btn-light-primary btn-sm mb-10 mt-3">
                                    <i class="ki-duotone ki-plus fs-2"></i> Create new Manufacturer
                                </a>
                                <!--end::Button-->
                                <!--begin::Input group-->
                                <div class="fv-row mb-7">
                                    <!--begin::Label-->
                                    <label class=" form-label">Manufacturer Code</label>
                                    <!--end::Label-->

                                    <!--begin::Input-->
                                    <input type="text" name="manufacturer_code" class="form-control mb-2"
                                        placeholder="Manufacturer Code..." value="<?php echo e($myProduct->manufacturer_code); ?>">
                                    <!--end::Input-->

                                    <?php $__errorArgs = ['manufacturer_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                    </div>
                                </div>
                                <!--end::Input group-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Category & tags-->
                       
                    </div>
                    <!--end::Aside column-->

                    <!--begin::Main column-->
                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                        <!--begin:::Tabs-->
                        <ul class="nav nav-custom nav-tabs nav-line-tabs nav-line-tabs-2x border-0 fs-4 fw-semibold mb-n2"
                            role="tablist">
                            <!--begin:::Tab item-->
                            <li class="nav-item" role="presentation">
                                <a class="nav-link text-active-primary pb-4 active" data-bs-toggle="tab"
                                    href="#kt_ecommerce_add_product_general" aria-selected="true" role="tab">Product
                                    Details</a>
                            </li>
                            <!--end:::Tab item-->

                        

                        </ul>
                        <!--end:::Tabs-->
                        <!--begin::Tab content-->
                        <div class="tab-content">
                            <!--begin::Tab pane-->
                            <div class="tab-pane fade show active" id="kt_ecommerce_add_product_general" role="tab-panel">
                                <div class="d-flex flex-column gap-7 gap-lg-10">

                                    <!--begin::General options-->
                                    <div class="card card-flush py-4">
                                        <!--begin::Card header-->
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Product Details</h2>
                                            </div>
                                        </div>
                                        <!--end::Card header-->

                                        <!--begin::Card body-->
                                        <div class="card-body pt-0">
                                            <!--begin::Input group-->
                                            <div class="mb-10 fv-row fv-plugins-icon-container">
                                                <!--begin::Label-->
                                                <label class="required form-label">SKU</label>
                                                <!--end::Label-->

                                                <!--begin::Input-->
                                                <input type="text" name="sku" class="form-control mb-2"
                                                    placeholder="Product SKU" value="<?php echo e(old('sku',$product->Sku)); ?>">
                                                <!--end::Input-->

                                                <!--begin::Description-->
                                                <div class="text-muted fs-7">A product sku is required and recommended to
                                                    be unique.</div>
                                                <!--end::Description-->
                                                <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div
                                                    class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <!--begin::Input group-->
                                            <div class="mb-10 fv-row fv-plugins-icon-container">
                                                <!--begin::Label-->
                                                <label class="required form-label"> Name</label>
                                                <!--end::Label-->

                                                <!--begin::Input-->
                                                <input type="text" name="name" class="form-control mb-2"
                                                    placeholder="Product name" value="<?php echo e(old('name',$product->Name)); ?>">
                                                <!--end::Input-->

                                                <!--begin::Description-->
                                                <div class="text-muted fs-7">A product name is required and recommended to
                                                    be unique.</div>
                                                <!--end::Description-->
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div
                                                    class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                          
                                            <!--begin::Input group-->
                                            <div class="mb-10 fv-row fv-plugins-icon-container">
                                                <!--begin::Label-->
                                                <label class="required form-label"> Price</label>
                                                <!--end::Label-->

                                                <!--begin::Input-->
                                                <input type="text" id="price" name="price"
                                                    class="form-control mb-2" placeholder="Product price"
                                                    value="<?php echo e($product->UnitPrice); ?>">
                                                <!--end::Input-->
                                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                <div
                                                    class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <!--begin::Input group-->
                                            <div class="mb-10 fv-row fv-plugins-icon-container">
                                                <!--begin::Label-->
                                                <label class="required form-label"> Cost</label>
                                                <!--end::Label-->

                                                <!--begin::Input-->
                                                <input type="text" id="cost" name="cost"
                                                    class="form-control mb-2" placeholder="Product cost"
                                                    value="<?php echo e($product->PurchaseCost); ?>">
                                                <!--end::Input-->
                                                <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                <div
                                                    class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <!--begin::Input group-->
                                            <div class="mb-10 fv-row fv-plugins-icon-container">
                                                <!--begin::Label-->
                                                <label class="required form-label"> Profit</label>
                                                <!--end::Label-->

                                                <!--begin::Input-->
                                                <input type="text" id="profit" name="profit"
                                                    class="form-control mb-2" placeholder="Product profit"
                                                    value="<?php echo e($product->UnitPrice - $product->PurchaseCost); ?>">
                                                <!--end::Input-->

                                                <?php $__errorArgs = ['profit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div
                                                    class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <!--begin::Input group-->
                                            <div class="mb-10 fv-row fv-plugins-icon-container">
                                                <!--begin::Label-->
                                                <label class=" form-label"> Pack</label>
                                                <!--end::Label-->
                                                <!--begin::Input-->
                                                <input type="text" id="pack" name="pack"
                                                    class="form-control mb-2" placeholder="Product pack"
                                                    value="<?php echo e(old('pack',$myProduct->pack)); ?>">
                                                <!--end::Input-->

                                                <?php $__errorArgs = ['pack'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div
                                                    class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                 

                                        </div>
                                        <!--end::Card header-->
                                    </div>
                                    <!--end::General options-->
                                 
                                </div>
                            </div>
                            <!--end::Tab pane-->


                        </div>
                        <!--end::Tab content-->

                        <div class="d-flex justify-content-end">
                            <!--begin::Button-->
                            <a href="<?php echo e(route('products')); ?>" id="kt_ecommerce_add_product_cancel"
                                class="btn btn-light me-5">
                                Cancel
                            </a>
                            <!--end::Button-->

                            <!--begin::Button-->
                            <button type="submit" id="kt_ecommerce_add_product_submit" class="btn btn-primary">
                                <span class="indicator-label">
                                    Save Changes
                                </span>
                                <span class="indicator-progress">
                                    Please wait... <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                                </span>
                            </button>
                            <!--end::Button-->
                        </div>
                    </div>
                    <!--end::Main column-->
                </form>
                <!--end::Form-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::Post-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(document).ready(function() {
            // Function to calculate and update profit percentage
            function calculateProfitPercentage() {
                // Get the price and cost values
                var price = parseFloat($('#price').val()) || 0;
                var cost = parseFloat($('#cost').val()) || 0;

                // Calculate the profit percentage
                var profitPercentage = (price - cost) / price * 100;

                // Update the profit input field
                $('#profit').val(profitPercentage.toFixed(2) + '%');
            }

            // Add event listeners to price and cost inputs
            $('#price, #cost').on('input', function() {
                calculateProfitPercentage();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asad/Projects/Lahore Projects/ERP/resources/views/admin/edit_product.blade.php ENDPATH**/ ?>