<?php $__env->startSection('content'); ?>
    <!--begin::Content-->
    <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Toolbar-->
        <div class="toolbar" id="kt_toolbar">
            <div class=" container-fluid  d-flex flex-stack flex-wrap flex-sm-nowrap">
                <!--begin::Info-->
                <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                    <!--begin::Title-->
                    <h1 class="text-dark fw-bold my-1 fs-2">
                        Dashboard <small class="text-muted fs-6 fw-normal ms-1"></small>
                    </h1>
                    <!--end::Title-->

                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb fw-semibold fs-base my-1">
                        <li class="breadcrumb-item text-muted">
                            <a href="<?php echo e(route('dashboard')); ?>" class="text-muted text-hover-primary">
                                Home </a>
                        </li>

                        <li class="breadcrumb-item text-muted">
                            Dashboard </li>


                    </ul>
                    <!--end::Breadcrumb-->
                </div>
                <!--end::Info-->

                
            </div>
        </div>
        <!--end::Toolbar-->

        <!--begin::Post-->
        <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div class=" container-fluid ">
                <!--begin::Row-->
                <div class="row g-xl-12">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row g-xl-12">
                            
                            
                            <!--begin::Col-->
                            <div class="col-xl-6">
                                <!--begin::Chart Widget 1-->
                                <div class="card  card-xl-stretch mb-5 mb-xl-8">
                                    <!--begin::Body-->
                                    <div class="card-body p-0 d-flex justify-content-between flex-column">
                                        <div class="d-flex flex-stack card-p flex-grow-1">
                                            <!--begin::Icon-->
                                            <div class="symbol symbol-45px">
                                                <div class="symbol-label"><i class="ki-duotone ki-basket fs-2x"><span
                                                            class="path1"></span><span class="path2"></span><span
                                                            class="path3"></span><span class="path4"></span></i></div>
                                            </div>
                                            <!--end::Icon-->

                                            <!--begin::Text-->
                                            <div class="d-flex flex-column text-end">
                                                <span class="fw-bolder text-gray-800 fs-2">Customers</span>
                                                
                                            </div>
                                            <!--end::Text-->
                                        </div>

                                        <!--begin::Chart-->
                                        <div class="pt-1">
                                            <div id="customer_chart" class="card-rounded-bottom h-125px"></div>
                                        </div>
                                        <!--end::Chart-->
                                    </div>
                                </div>
                                <!--end::Chart Widget 1-->
                            </div>
                            <!--end::Col-->
                            
                            <!--begin::Col-->
                            <div class="col-xl-6">
                                <!--begin::Chart Widget 1-->
                                <div class="card  card-xl-stretch mb-5 mb-xl-8">
                                    <!--begin::Body-->
                                    <div class="card-body p-0 d-flex justify-content-between flex-column">
                                        <div class="d-flex flex-stack card-p flex-grow-1">
                                            <!--begin::Icon-->
                                            <div class="symbol symbol-45px">
                                                <div class="symbol-label"><i class="ki-duotone ki-basket fs-2x"><span
                                                            class="path1"></span><span class="path2"></span><span
                                                            class="path3"></span><span class="path4"></span></i></div>
                                            </div>
                                            <!--end::Icon-->

                                            <!--begin::Text-->
                                            <div class="d-flex flex-column text-end">
                                                <span class="fw-bolder text-gray-800 fs-2">Products</span>
                                            </div>
                                            <!--end::Text-->
                                        </div>

                                        <!--begin::Chart-->
                                        <div class="pt-1">
                                            <div id="product_chart" class="card-rounded-bottom h-125px"></div>
                                        </div>
                                        <!--end::Chart-->
                                    </div>
                                </div>
                                <!--end::Chart Widget 1-->
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                        
                        <!--begin::Col-->
                        <div class="col-xl-12">
                            <!--begin::Chart Widget 1-->
                            <div class="card  card-xl-stretch mb-5 mb-xl-8">
                                <!--begin::Body-->
                                <div class="card-body p-0 d-flex justify-content-between flex-column">
                                    <div class="d-flex flex-stack card-p flex-grow-1">
                                        <!--begin::Icon-->
                                        <div class="symbol symbol-45px">
                                            <div class="symbol-label"><i class="ki-duotone ki-basket fs-2x"><span
                                                        class="path1"></span><span class="path2"></span><span
                                                        class="path3"></span><span class="path4"></span></i></div>
                                        </div>
                                        <!--end::Icon-->

                                        <!--begin::Text-->
                                        <div class="d-flex flex-column text-end">
                                            <span class="fw-bolder text-gray-800 fs-2">Sales</span>
                                            
                                        </div>
                                        <!--end::Text-->
                                    </div>

                                    <!--begin::Chart-->
                                    <div class="pt-1">
                                        <div id="sales_chart" class="card-rounded-bottom h-125px"></div>
                                    </div>
                                    <!--end::Chart-->
                                </div>
                            </div>
                            <!--end::Chart Widget 1-->
                        </div>
                        <!--end::Col-->
                    </div>
                    <!--end::Col-->

                    
                </div>
                <!--end::Row-->

                

                
            </div>
            <!--end::Container-->
        </div>
        <!--end::Post-->
    </div>
    <!--end::Content-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Data from the server
            const months = <?php echo json_encode($customerMonths, 15, 512) ?>;
            const customerCounts = <?php echo json_encode($customerCounts, 15, 512) ?>;

            // ApexCharts options
            var customerOptions = {
                series: [{
                    name: 'Number of Customers',
                    data: customerCounts
                }],
                chart: {
                    height: 350,
                    type: 'line'
                },
                xaxis: {
                    categories: months,
                    title: {
                        text: 'Months'
                    }
                },
                yaxis: {
                    title: {
                        text: 'Number of Customers'
                    }
                },
                title: {
                    text: 'Monthly Customer Count',
                    align: 'left'
                }
            };

            // Render the chart
            var chart = new ApexCharts(document.querySelector("#customer_chart"), customerOptions);
            chart.render();


            // product analytics
  // Data from the server
  const productMonths = <?php echo json_encode($productMonths, 15, 512) ?>;
    const productCounts = <?php echo json_encode($productCounts, 15, 512) ?>;

    // ApexCharts options for products
    var productOptions = {
        series: [{
            name: 'Number of Products',
            data: productCounts
        }],
        chart: {
            height: 350,
            type: 'line'
        },
        xaxis: {
            categories: productMonths,
            title: {
                text: 'Months'
            }
        },
        yaxis: {
            title: {
                text: 'Number of Products'
            }
        },
        title: {
            text: 'Monthly Product Count',
            align: 'left'
        }
    };

    // Render the product chart
    var productChart = new ApexCharts(document.querySelector("#product_chart"), productOptions);
    productChart.render();
            //sales analytics      
            var options = {
                chart: {
                    type: 'line',
                    height: '250px'
                },
                series: [{
                    name: 'Sales',
                    data: <?php echo json_encode($sales, 15, 512) ?>
                }],
                xaxis: {
                    categories: <?php echo json_encode($months, 15, 512) ?>
                },
                yaxis: {
                    labels: {
                        formatter: function(value) {
                            return '$' + value;
                        }
                    }
                },
                tooltip: {
                    y: {
                        formatter: function(value) {
                            return '$' + value;
                        }
                    }
                }
            };

            var chart = new ApexCharts(document.querySelector("#sales_chart"), options);
            chart.render();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asad/Projects/Lahore Projects/ERP/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>