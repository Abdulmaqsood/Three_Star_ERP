<?php if(Session::has('sweetalert.alert')): ?>
    <script>
        let config = <?php echo Session::pull('sweetalert.alert'); ?>

        Swal.fire(config)
    </script>
<?php endif; ?>
<?php /**PATH /home/asad/Projects/Lahore Projects/ERP/vendor/wavey/sweetalert/src/../views/sweetalert.blade.php ENDPATH**/ ?>