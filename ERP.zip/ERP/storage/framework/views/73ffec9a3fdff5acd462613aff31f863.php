<?php $__env->startPush('custom-css'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <table class="table ">
            <tbody>
                <tr>
                    <td class="border-0 pl-0" width="70%">
                        <img src="<?php echo e(asset('assets/media/logo.svg')); ?>" alt="logo" height="70">

                        
                    </td>
                    <td class="border-0 pl-0">
                        
                        <h4 class="text-uppercase cool-gray">
                            <strong>Invoice</strong>
                        </h4>
                        
                        <?php
                            use Carbon\Carbon;

                        ?>
                        <p class="m-0">Due Date: <strong> <?php echo e($invoice->DueDate); ?></strong></p>
                        <p class="m-0">Invoice # :<strong> <?php echo e($invoice->DocNumber); ?></strong></p>
                        
                    </td>
                </tr>
            </tbody>
        </table>

        <table class="table">
            
            <tbody>
                <tr>
                    <td class="px-0">
                        <?php if($company): ?>
                            <p class="">
                                <strong><?php echo e($company->name); ?></strong>
                            </p>


                            <p class="m-0">
                                <?php echo e($company->address); ?>,
                            </p>

                            <p class="m-0">
                                <?php echo e($company->contact_number); ?>

                            </p>

                            <p class="m-0">
                                <?php echo e($company->email); ?>

                            </p>
                            <p class="m-0">
                                <?php echo e($company->registration_number); ?>

                            </p>
                            <p class="m-0">
                                <?php echo e($company->business_number); ?>

                            </p>
                        <?php endif; ?>

                    </td>
                </tr>
            </tbody>
        </table>
        <div class="separator border-primary my-5"></div>

        <div class="d-flex">
            
            <table class="table">
                <thead>
                    <tr>
                        <th class="border-0 pl-0 party-header text-primary fw-bold fs-4" width="48.5%">
                            Billing To
                        </th>

                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td class="px-0">
                            <?php if($invoice->BillAddr): ?>
                                


                                <p class="m-0">
                                    <?php echo e($invoice->BillAddr->Line1 ?? $customer->BillAddr->Line1); ?>

                                </p>
                                <p class="m-0">
                                    <?php echo e($invoice->BillAddr->City ?? $customer->BillAddr->City); ?>

                                </p>
                                
                                <p class="m-0">
                                    <?php echo e($invoice->BillAddr->Country ?? $customer->BillAddr->Country); ?>

                                </p>
                                
                            <?php else: ?>
                                <p class="m-0">
                                    <strong><?php echo e($customer->DisplayName); ?></strong>
                                </p>

                                <p class="m-0">
                                    <?php echo e($customer->BillAddr->Line1 ?? ""); ?>

                                </p>
                                <p class="m-0">
                                    <?php echo e($customer->BillAddr->City ?? ""); ?>

                                </p>
                                
                                <p class="m-0">
                                    <?php echo e($customer->BillAddr->Country ?? ""); ?>

                                </p>
                                <p class="m-0"><?php echo e($customer->PrimaryPhone->FreeFormNumber ?? ''); ?> </p>

                            <?php endif; ?>
                            
                        </td>
                    </tr>
                </tbody>
            </table>

            <table class="table">
                <thead>
                    <tr>
                        <th class="border-0 pl-0 party-header text-primary fw-bold fs-4" width="48.5%">
                            Shipping To
                        </th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="px-0">
                            <?php if($invoice->ShipAddr): ?>
                                <p class="m-0">
                                    <strong><?php echo e($customer->DisplayName); ?></strong>
                                </p>

                                <p class="m-0"><?php echo e($invoice->ShipAddr ? $invoice->ShipAddr->Line1 : $customer->ShipAddr->Line1); ?> </p>
                                <p class="m-0"><?php echo e($invoice->ShipAddr ? $invoice->ShipAddr->City : $customer->ShipAddr->City); ?> </p>
                                <p class="m-0"><?php echo e($invoice->ShipAddr ? $invoice->ShipAddr->Country : $customer->ShipAddr->Country); ?> </p>
                                <p class="m-0"><?php echo e($customer->PrimaryPhone->FreeFormNumber ?? ''); ?> </p>
                            <?php else: ?>
                                <p class="m-0">
                                    <strong><?php echo e($customer->DisplayName); ?></strong>
                                </p>

                                <p class="m-0"><?php echo e($customer->ShipAddr ? $customer->ShipAddr->Line1 : ''); ?> </p>
                                <p class="m-0"><?php echo e($customer->ShipAddr ? $customer->ShipAddr->City : ''); ?> </p>
                                <p class="m-0"><?php echo e($customer->ShipAddr ? $customer->ShipAddr->Country : ''); ?> </p>
                                <p class="m-0"><?php echo e($customer->PrimaryPhone->FreeFormNumber ?? ''); ?> </p>
                            <?php endif; ?>
                            
                        </td>
                    </tr>
                </tbody>
            </table>
            
        </div>

        
        <table class="table table-items mt-2">
            <thead>
                <tr class="bg-primary text-white fw-bold  rounded">
                    <th scope="col" class="border-0 ps-3 fs-6"> Sku</th>
                    <th scope="col" class="border-0 ps-3 fs-6"> Product Name</th>
                    
                    
                    
                    <th scope="col" class="text-center border-0 fs-6"> Pack</th>
                    <th scope="col" class="text-center border-0 fs-6">Rate</th>
                    
                    
                    
                    
                    <th scope="col" class="text-center border-0 fs-6"> </th>
                    
                    <th scope="col" class="text-center border-0 fs-6">Amount</th>
                </tr>
            </thead>
            <tbody>

                <?php if($invoice->Line): ?>
                    <?php
                        $invoiceLines = $invoice->Line;

                        array_pop($invoiceLines);
                    ?>
                    
                    <?php $__currentLoopData = $invoiceLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="pl-0">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->SalesItemLineDetail->ItemRef == $product->quickbook_id): ?>
                                        <?php echo e($product->sku); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td class="pl-0">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->SalesItemLineDetail->ItemRef == $product->quickbook_id): ?>
                                        <?php echo e($product->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td class="text-center"><?php echo e($item->SalesItemLineDetail->Qty); ?></td>


                            <td class="text-center">
                                <?php echo e($item->SalesItemLineDetail->UnitPrice); ?>$
                            </td>
                            

                            
                            
                            
                            

                            <td class="text-center pr-0">
                                
                            </td>
                            
                            <td class="text-center"><?php echo e($item->Amount); ?>$</td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    <tr>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="pl-0 text-primary fw-bold fs-4">Subtotal</td>
                        <td class="text-center text-primary fw-bold fs-4">
                            <?php echo e($invoice->TotalAmt); ?>$
                        </td>
                    </tr>
                    
                    
                    <tr>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class=" pl-0 text-primary fw-bold fs-4">Tax (HST/GST @ 13%)</td>
                        <td class="text-center text-primary fw-bold fs-4 ">
                            <?php echo e($invoice->tax ?? 0); ?>$
                        </td>
                    </tr>
                    
                    
                    <tr>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class=" pl-0 text-primary fw-bold fs-4">Total</td>
                        <td class="text-center text-primary fw-bold fs-4  total-amount">
                            <?php echo e($invoice->TotalAmt ?? ''); ?>$
                        </td>
                    </tr>
                    
                    
                    
                    
                <?php endif; ?>

            </tbody>
        </table>

        
        
        

        

        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asad/Projects/Lahore Projects/ERP/resources/views/admin/show_invoice.blade.php ENDPATH**/ ?>