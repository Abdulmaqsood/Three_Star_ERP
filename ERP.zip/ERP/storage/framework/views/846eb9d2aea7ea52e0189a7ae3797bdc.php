  <!--begin::Footer-->
  <div class="footer py-4 d-flex flex-lg-column " id="kt_footer">
    <!--begin::Container-->
    <div class=" container-fluid  d-flex flex-column flex-md-row flex-stack">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-semibold me-2">2024&copy;</span>

            <a href="#" target="_blank"
                class="text-gray-800 text-hover-primary">Three Star</a>
        </div>
        <!--end::Copyright-->

        
    </div>
    <!--end::Container-->
</div>
<!--end::Footer--><?php /**PATH /home/asad/Projects/Lahore Projects/ERP/resources/views/layout/admin/footer.blade.php ENDPATH**/ ?>