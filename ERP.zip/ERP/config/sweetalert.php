<?php

return [
    /*
     * This sets the global autoclose for all alerts.
     * If you want to change a specific  alert chain ->autoclose(milliseconds) on the end.
     */
    'autoclose' => 2500,
];
