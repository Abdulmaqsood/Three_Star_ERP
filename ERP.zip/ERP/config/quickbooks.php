<?php

return [

   'client_id' => env('QUICKBOOKS_CLIENT_ID'),
   'client_secret' => env('QUICKBOOKS_CLIENT_SECRET'),
   'redirect_uri' => env('QUICKBOOKS_REDIRECT_URI'),
   'access_token' => env('QUICKBOOKS_ACCESS_TOKEN'),
   'refresh_token' => env('QUICKBOOKS_REFRESH_TOKEN'),
   'realm_id' => env('QUICKBOOKS_REALM_ID'),
   'base_url' => env('QUICKBOOKS_BASE_URL'),
];
